# # GoidTokenData

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**otp** | **string** | OTP from whatsapp or SMS | [optional]
**otp_token** | **string** | OTP token from login request | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
