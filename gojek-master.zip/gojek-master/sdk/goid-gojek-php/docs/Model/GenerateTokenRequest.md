# # GenerateTokenRequest

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**client_id** | **string** |  | [optional] [default to 'gojek:consumer:app']
**client_secret** | **string** |  | [optional] [default to 'pGwQ7oi8bKqqwvid09UrjqpkMEHklb']
**data** | [**\GoIdGojekPhp\Model\GoidTokenData**](GoidTokenData.md) |  | [optional]
**grant_type** | **string** |  | [optional] [default to 'otp']
**scopes** | **mixed[]** |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
