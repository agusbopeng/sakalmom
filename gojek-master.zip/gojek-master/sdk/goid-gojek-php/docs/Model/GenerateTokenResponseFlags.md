# # GenerateTokenResponseFlags

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**onetap_eligible** | **bool** |  | [optional]
**is_app_pin_set** | **bool** |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
