# # LoginRequestResponseData

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**otp_token** | **string** |  | [optional]
**otp_expires_in** | **float** |  | [optional]
**otp_length** | **float** |  | [optional]
**next_state** | [**\GoIdGojekPhp\Model\LoginRequestResponseDataNextState**](LoginRequestResponseDataNextState.md) |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
