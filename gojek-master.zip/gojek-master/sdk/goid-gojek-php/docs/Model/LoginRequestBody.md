# # LoginRequestBody

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**client_id** | **string** |  | [optional] [default to 'gojek:consumer:app']
**client_secret** | **string** |  | [optional] [default to 'pGwQ7oi8bKqqwvid09UrjqpkMEHklb']
**country_code** | **string** |  | [optional] [default to '+62']
**login_type** | **string** | possible value: otp_whatsapp, sms | [optional] [default to 'otp_whatsapp']
**magic_link_ref** | **string** |  | [optional]
**phone_number** | **string** |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
