# # LoginRequestResponse

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**data** | [**\GoIdGojekPhp\Model\LoginRequestResponseData**](LoginRequestResponseData.md) |  | [optional]
**success** | **bool** |  | [optional]
**errors** | **mixed[]** |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
